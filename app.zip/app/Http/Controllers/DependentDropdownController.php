<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Laravolt\Indonesia\Models\Province;
use Laravolt\Indonesia\Models\City;
use App\Models\Kota;

class DependentDropdownController extends Controller
{
    public function index()
    {
        $cities = Kota::pluck('name', 'province_id');
        $provinces = Province::pluck('name', 'id');
        return view(
            'data',
            [
                'provinces' => $provinces,
                'cities' => $cities
            ]


        );
    }
}
