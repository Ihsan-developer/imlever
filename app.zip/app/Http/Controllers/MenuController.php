<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MenuController extends Controller
{
    // Start
    public function home()
    {
        return view('index');
    }
    public function dashboard()
    {
        return view('dashboard');
    }
    public function top_global_to()
    {
        return view('top');
    }
    public function to()
    {
        return view('to.to1');
    }
}
