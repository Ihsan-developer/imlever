@extends('layouts.app')

@section('content')

<h3>Data top global</h3>
<table class="table-bordered table-striped">
    <tr>
        <th>Nama</th>
        <th>NIS</th>
        <th>Tanggal Lahir</th>
    </tr>
    <tr>
        <th>Andi</th>
        <th>2131241</th>
        <th>2004-01-23</th>
    </tr>
    <tr>
        <th>Rian</th>
        <th>2131241</th>
        <th>2004-01-23</th>
    </tr>
</table>

@endsection