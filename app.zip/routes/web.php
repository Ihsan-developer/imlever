<?php

use App\Http\Controllers\SiswaController;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\DependentDropdownController;
use GuzzleHttp\Middleware;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| 
*/

Route::get('/', function () {
    return view('index');
});

Route::get('/index', [MenuController::class, 'home']);
Route::get('/dashboard', [MenuController::class, 'dashboard']);
Route::get('/top', [MenuController::class, 'top_global_to']);
Route::get('/to', [MenuController::class, 'to']);
/*
Route::get('/data', [DependentDropdownController::class, 'index']);*/


Auth::routes(['verify' => True]);

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::resource('siswa', SiswaController::class)->middleware('can:isAdmin');
Route::resource('siswa', SiswaController::class)->only('show')->middleware('can:isAdminSiswa');
