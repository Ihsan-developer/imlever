

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h3>Tambah Siswa</h3>
        </div>
        <div class="card-body">
            <a href="<?php echo e(route ('siswa.index')); ?>" class="btn btn-primary">Kembali</a>
            <form action="<?php echo e(route('siswa.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <ul class="list-group">
                    Nama <input type="text" name="nama" required>
                    NIS <input type="text" name="nis" required>
                    Tanggal Lahir <input type="date" name="tgl_lahir" required>
                </ul>
                <input type="submit" value="Simpan Data" class="btn btn-success">
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imlever\resources\views/form_tambah.blade.php ENDPATH**/ ?>