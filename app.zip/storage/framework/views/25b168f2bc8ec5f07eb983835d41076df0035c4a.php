

<?php $__env->startSection('content'); ?>
<div class="container d-flex justify-content-center">
    <div class="card w-50">
        <div class="card-header">
            <h3>Profil Siswa</h3>
        </div>
        <div class="card-body">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
            <a href="<?php echo e(route ('siswa.index')); ?>">Kembali</a>
            <?php endif; ?>
            <div class="row ml-2">
                <h4 class="col-4">Nama</h4>
                <h4>: <?php echo e($siswa->nama); ?></h4>
            </div>
            <div class="row ml-2">
                <h4 class="col-4">Nama</h4>
                <h4>: <?php echo e($siswa->nis); ?></h4>
            </div>
            <div class="row ml-2">
                <h4 class="col-4">Nis</h4>
                <h4>: <?php echo e($siswa->tgl_lahir); ?></h4>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imlever\resources\views/profil_siswa.blade.php ENDPATH**/ ?>