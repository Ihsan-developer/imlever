

<?php $__env->startSection('content'); ?>

<!-- start section hero -->

<section class="hero">
    <div class="h-100 d-flex align-items-center">
        <div class="container">
            <div class="row text-center text-lg-start">

                <!-- start left side -->
                <div class="
                col-12 col-sm-1  
                order-0 order-lg-0
                ">


                </div>
                <!-- end left side -->

                <!-- Start Mid Side -->
                <div class="
                col-12 col-sm-10  
                text-black
                align-self-center
                order-1 order-lg-1 my-5 my-lg-0
                ">
                    <div class="card" id="card">

                        <div class="card-body">
                            <form method="POST" action="#">
                                <?php echo csrf_field(); ?>

                                <div class="form-group row mb-3 ">
                                    <!--Left-->
                                    <div class="col-12 col-sm-6">
                                        <label for="negara" class="col-md-4 col-form-label text-md-right text-start"><?php echo e(__('Negara')); ?></label>

                                        <div class="#">
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected></option>
                                                <option value="1">Indonesia</option>

                                            </select>

                                            <!--<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>-->
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <!--<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
                                        </div>
                                    </div>
                                    <!--Right-->
                                    <div class="col-12 col-sm-6">

                                        <label for="sekolah" class="col-md-4 col-form-label text-md-right text-start"><?php echo e(__('Nama Sekolah')); ?></label>

                                        <div class="#">
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected></option>
                                                <option value="1">Indonesia</option>

                                            </select>

                                            <!--<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>-->
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <!--<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
                                        </div>
                                    </div>
                                </div>


                                <div class="form-group row mb-3 ">
                                    <!--Left-->
                                    <div class="col-12 col-sm-6">
                                        <label for="province" class="col-md-4 col-form-label text-md-right text-start"><?php echo e(__('Provinsi')); ?></label>

                                        <div class="#">
                                            <select class="form-select" id="province" name="province" aria-label="Default select example">
                                                <option selected></option>
                                                <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $provinsi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($id); ?>"><?php echo e($provinsi); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>

                                        </div>
                                    </div>

                                    <!--Right-->
                                    <div class="col-12 col-sm-6">

                                        <label for="negara" class="col-md-4 col-form-label text-md-right text-start"><?php echo e(__('Negara')); ?></label>

                                        <div class="#">
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected></option>
                                                <option value="1">Indonesia</option>

                                            </select>


                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row mb-3 ">


                                    <!--Left-->
                                    <div class="col-12 col-sm-6">
                                        <label for="city" class="col-md-4 col-form-label text-md-right text-start"><?php echo e(__('Kota')); ?></label>

                                        <div class="#">
                                            <select class="form-select" id="city" name="city" aria-label="Default select example">
                                                <option selected></option>

                                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province_id => $kota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                if ($province_id == $id){

                                                <option value="<?php echo e($province_id); ?>"><?php echo e($kota); ?></option>
                                                }
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>


                                        </div>
                                    </div>
                                    <!--Right-->
                                    <div class="col-12 col-sm-6">

                                        <label for="negara" class="col-md-4 col-form-label text-md-right text-start"><?php echo e(__('Negara')); ?></label>

                                        <div class="#">
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected></option>
                                                <option value="1">Indonesia</option>

                                            </select>


                                        </div>
                                    </div>
                                </div>


                            </form>
                        </div>
                    </div>
                </div>
                <!-- End of Mid Side -->

                <!-- start right side -->
                <div class="
                col-12 col-sm-1
                order-2 order-lg-2
                ">
                </div>
                <!-- end right side -->
            </div>
        </div>
    </div>
</section>
<!-- end section hero -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imlever\resources\views/data.blade.php ENDPATH**/ ?>