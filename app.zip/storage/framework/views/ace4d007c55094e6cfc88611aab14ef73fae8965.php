

<?php $__env->startSection('content'); ?>


<!-- start section hero -->
<section class="hero" id="hero">
    <div class="h-100 d-flex align-items-center">
        <div class="container" id="hero_" style="margin-top: -55px">
            <div class="row text-center text-lg-start">
                <!-- start left side -->
                <div class="
                col-12 col-sm-6
                text-white
                align-self-center
                order-1 order-lg-0
              " style="margin-top: -50px">
                    <h1 class="main-text fw-bold">
                        Bangun Projectmu<br />
                        dengan mendapatkan <br />
                        source code terbaik <br />
                    </h1>
                    <p class="fw-bold lh-lg mt-4">
                        Belajar bangun project IT pertamamu dengan mendapatkan <br />
                        source code terbaik dari kami
                    </p>
                    <!--<form action="#">
                <div class="row g-3 align-items-center">
                  <div class="col-12 col-lg-auto">
                    <input
                      type="email"
                      id="email"
                      class="form-control"
                      placeholder="Your Email Address"
                    />
                  </div>
                  <div class="col-12 col-lg-auto text-center">
                    <button type="submit" class="btn btn-primary">
                      Subscribe Now
                    </button>
                  </div>
                </div>
              </form>-->
                </div>
                <!-- end left side -->

                <!-- start right side -->
                <div class="col-12 col-sm-6 order-0 order-lg-1 my-5 my-lg-0">
                    <img src="<?php echo e(asset('img/hero.png')); ?>" id="hero" alt="Hero illustration" class="img-fluid" heigth="1200px" width="1200px" />
                </div>
                <!-- end right side -->
            </div>
        </div>
    </div>
</section>
<!-- end section hero -->`

<!-- start section card feature -->
<section class="container" id="data">
    <div class="card shadow card-feature">
        <div class="card-body p-4 p-lg-5" style="margin-top: -50px">
            <div class="row gx-5 gy-5 gy-lg-0">
                <h2 class="text-center" id="judulbenefit">
                    Manfaat Mendapatkan Source Code
                </h2>
                <!-- start column 1st -->
                <div class="col-12 col-sm-4 card-feature-body position-relative">
                    <figure class="text-center" style="height: 120px">
                        <a href="https://pngtree.com/so/arrow"><img src="images/illustration1.png" id="il1" alt="illustration 1" class="img-fluid" style="height: auto; width: 90%" /></a>
                    </figure>
                    <h2 class="fs-5 text-heading">Efektif</h2>
                    <p class="lh-lg" style="text-align: justify">
                        Dengan mendapatkan source code yang kamu inginkan, kamu bisa
                        menambah fitur menarik dan bervariasi yang belum pernah ketahui
                        sebelumnya untuk projectmu
                    </p>
                    <a href="#" class="btn btn-outline-primary position-absolute bottom-0" id="tombol">Detail</a>
                </div>
                <!-- end column 1st -->

                <!-- start column 2nd -->
                <div class="col-12 col-sm-4 card-feature-body position-relative">
                    <figure class="text-center" style="height: 120px">
                        <img src="images/illustration2.svg" id="il2" alt="illustration 2" class="img-fluid" style="height: auto; width: 50%" />
                    </figure>
                    <h2 class="fs-5 text-heading">Efisien</h2>
                    <p class="lh-lg" style="text-align: justify">
                        Kamu dapat menghemat waktu dalam membangun sebuah project. Dan
                        hanya tinggal mengedit content dari source code kamu.
                    </p>
                    <a href="#" class="btn btn-outline-primary position-absolute bottom-0" id="tombol">Detail</a>
                </div>
                <!-- end column 2nd -->

                <!-- start column 3rd -->
                <div class="col-12 col-sm-4 card-feature-body position-relative">
                    <figure class="text-center" style="height: 120px">
                        <img src="images/illustration3.png" id="il3" alt="illustration 3" class="img-fluid" />
                    </figure>
                    <h2 class="fs-5 text-heading test">Bermanfaat</h2>
                    <p class="lh-lg" style="text-align: justify">
                        Selain efektif dan efisien, kamu dapat mempelajari cara
                        mengaplikasikan teknologi software/framework sehingga dapat
                        menambah skill developermu.
                    </p>
                    <a href="#" class="btn btn-outline-primary position-absolute bottom-0" id="tombol">Detail</a>
                </div>
                <!-- end column 3rd -->
            </div>
        </div>
    </div>
</section>
<!-- end section card feature -->

<!-- start section Our company -->
<section class="container section-taste-premium section-auto-flip" data-aos="fade-up">
    <div class="row">
        <div class="col-12 col-sm-6">
            <div class="canvas">
                <!--<div class="circle"></div>-->
                <div class="object">
                    <img src="images/logo_pt.png" alt="Pohon Jeruk" class="img-fluid" id="img-1" />
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 text-center text-lg-end align-self-center">
            <h3 class="text-main-orange display-5" id="about">
                About Our Company
            </h3>
            <h4 class="text-blue-jeans fs-2">PT. Anakos | Sahabat Anak Kos</h4>
            <p class="lh-lg" style="text-align: justify">
                Scarcely on striking packages by so property in delicate. Up or well
                must less rent read walk so be. Easy sold at do hour sing spot. Any
                meant has cease too the decay. Since party burst am it match. By or
                blushes between besides offices noisier as. Sending do brought
                winding compass in. Paid day till shed only fact age its end.
                Savings her pleased are several started females met. Short her not
                among being any. Thing of judge fruit charm views do. Miles mr an
                forty along as he. She education get middleton day agreement
                performed preserved unwilling. Do however as pleased offence outward
                beloved by present. By outward neither he so covered amiable
                greater. Juvenile proposal betrayed he an informed weddings
                followed. Precaution day see imprudence sympathize principles. At
                full leaf give quit to in they up.
            </p>
        </div>
    </div>
</section>
<!-- end section taste premium -->

<!-- start section taste premium -->
<section data-aos="fade-up" data-aos-duration="2000" class="container section-taste-premium section-auto-flip" id="testimonial">
    <div class="row" id="product">
        <div class="col-12 col-sm-6">
            <div class="canvas">
                <!--<div class="circle"></div>-->
                <div class="object">
                    <img src="images/produk.png" alt="Pohon Jeruk" class="img-fluid" id="img-2" />
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 text-center text-lg-end align-self-center">
            <h3 class="text-main-orange display-5" id="premium-1">
                Produk Mie Kos
            </h3>
            <h4 class="text-blue-jeans fs-2" id="text-premium-1">
                Lebih berkualitas
            </h4>
            <p class="lh-lg" style="text-align: justify">
                Scarcely on striking packages by so property in delicate. Up or well
                must less rent read walk so be. Easy sold at do hour sing spot. Any
                meant has cease too the decay. Since party burst am it match. By or
                blushes between besides offices noisier as. Sending do brought
                winding compass in. Paid day till shed only fact age its end.
                Savings her pleased are several started females met. Short her not
                among being any. Thing of judge fruit charm views do. Miles mr an
                forty along as he. She education get middleton day agreement
                performed preserved unwilling. Do however as pleased offence outward
                beloved by present. By outward neither he so covered amiable
                greater. Juvenile proposal betrayed he an informed weddings
                followed. Precaution day see imprudence sympathize principles. At
                full leaf give quit to in they up.
            </p>
        </div>
    </div>
</section>
<!-- end section taste premium -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imlever\resources\views/index.blade.php ENDPATH**/ ?>