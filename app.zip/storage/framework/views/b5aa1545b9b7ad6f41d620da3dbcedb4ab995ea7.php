<?php $__env->startSection('content'); ?>
<!-- start section hero -->

<section class="hero">
    <div class="h-100 d-flex align-items-center">
        <div class="container">
            <div class="row text-center text-lg-start">

                <!-- start right side -->
                <div class="
                col-12 col-sm-6   
                text-black
                align-self-center
                order-1 order-lg-1 my-5 my-lg-0
                ">

                    <div class="card" id="card">

                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('login')); ?>">
                                <?php echo csrf_field(); ?>

                                <div class="form-group row mb-3 ">
                                    <label for="email" class="col-md-4 col-form-label text-md-right text-start"><?php echo e(__('E-Mail Address')); ?></label>

                                    <div class="#">
                                        <input placeholder="contoh@gmail.com" id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="form-group row mb-3">
                                    <label for="password" class="col-md-4 col-form-label text-md-right text-start"><?php echo e(__('Password')); ?></label>

                                    <div class="#">
                                        <input placeholder="password" id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="form-group row mb-3">
                                    <?php if(Route::has('password.request')): ?>
                                    <div class="col-12 col-sm-6 text-start">
                                        <input class="btn btn-primary text-start" type="button" name="submit" value="Show" id="show" onclick="ShowPassword()" />
                                        <input class="btn btn-primary text-start" type="button" style="display: none" id="hide" value="Hide" onclick="HidePassword()" />

                                    </div>
                                    <div class="col-12 col-sm-6 text-end">
                                        <a href="<?php echo e(route('password.request')); ?>">
                                            <?php echo e(__('Lupa Password')); ?>

                                        </a>


                                    </div>
                                    <?php endif; ?>

                                </div>

                                <div class="form-group row mb-3">
                                    <div class="#">
                                        <div class="form-check text-start">
                                            <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                            <label class="form-check-label" for="remember">
                                                <?php echo e(__('Tolong Ingat Akunku')); ?>

                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row mb-3">
                                    <div class="#">
                                        <button type="submit" class="btn btn-primary" id="button">
                                            <?php echo e(__('Masuk')); ?>

                                        </button>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="#">
                                        <div class="row ">
                                            <div class="col-12 text-center">
                                                <span>Belum Punya Akun?</span> <a class="btn btn-link" href="<?php echo e(route('register')); ?>">
                                                    Daftar di sini
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- end right side -->

                <!-- start left side -->
                <div class="
                col-12 col-sm-6
                order-0 order-lg-0
                ">
                    <a href='https://www.freepik.com/vectors/illustrations' target="_blank"><img src="<?php echo e(asset('img/login.png')); ?>" alt="Hero illustration" class="img-fluid element-3" id="img-login" /></a>

                </div>
                <!-- end left side -->
            </div>
        </div>
    </div>
</section>
<!-- end section hero -->


<div class="row justify-content-center">
    <div class="col-md-8">

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imlever\resources\views/auth/login.blade.php ENDPATH**/ ?>