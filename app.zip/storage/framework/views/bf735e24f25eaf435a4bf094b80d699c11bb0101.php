

<?php $__env->startSection('content'); ?>

<h3>Data top global</h3>
<table class="table-bordered table-striped">
    <tr>
        <th>Nama</th>
        <th>NIS</th>
        <th>Tanggal Lahir</th>
    </tr>
    <tr>
        <th>Andi</th>
        <th>2131241</th>
        <th>2004-01-23</th>
    </tr>
    <tr>
        <th>Rian</th>
        <th>2131241</th>
        <th>2004-01-23</th>
    </tr>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imlever\resources\views/top.blade.php ENDPATH**/ ?>