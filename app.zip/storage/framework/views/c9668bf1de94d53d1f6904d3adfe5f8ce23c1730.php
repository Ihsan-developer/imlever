

<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="card">
        <div class="card-header">
            <h3>Data top Global</h3>
        </div>
        <div class="card-body">
            <a href="<?php echo e(route('siswa.create')); ?>">Tambah Data Siswa</a>
            <table class="table-bordered table-striped">
                <tr>
                    <th>Nama</th>
                    <th>NIS</th>
                    <th>Tanggal Lahir</th>
                    <th>Aksi</th>
                </tr>
                <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($s->nama); ?></td>
                    <td><?php echo e($s->nis); ?></td>
                    <td><?php echo e($s->tgl_lahir); ?></td>
                    <td>
                        <ul class="nav">
                            <a href="<?php echo e(route ('siswa.show', $s->id)); ?>" class="btn btn-success mr-2">Show</a>
                            <a href="<?php echo e(route ('siswa.edit', $s->id)); ?>" class="btn btn-primary mr-2">Edit</a>
                            <form action="<?php echo e(route ('siswa.destroy', $s->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-warning">Delete</button>
                            </form>
                        </ul>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imlever\resources\views/index1.blade.php ENDPATH**/ ?>