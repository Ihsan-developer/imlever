[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/imlx3689/public_html/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>