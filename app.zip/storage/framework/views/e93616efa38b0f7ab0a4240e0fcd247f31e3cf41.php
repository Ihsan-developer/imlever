

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h3>Ubah Data Siswa</h3>
        </div>
        <div class="card-body">
            <a href="<?php echo e(route('siswa.index')); ?>" class="btn btn-primary">Kembali</a>
            <form action="<?php echo e(route('siswa.update', $siswa->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <ul class="list-group">
                    Nama <input type="text" name="nama" value="<?php echo e($siswa->nama); ?>" required>
                    NIS <input type="text" name="nis" value="<?php echo e($siswa->nis); ?>" required>
                    Tanggal Lahir <input type="date" name="tgl_lahir" value="<?php echo e($siswa->tgl_lahir); ?>" required>
                </ul>
                <input type="submit" value="Ubah data" class="btn btn-success">
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imlever\resources\views/form_ubah.blade.php ENDPATH**/ ?>