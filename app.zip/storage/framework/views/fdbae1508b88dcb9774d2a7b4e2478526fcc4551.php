<?php echo e($slot); ?>

<?php /**PATH /home/imlx3689/public_html/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>